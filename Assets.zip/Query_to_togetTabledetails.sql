--Old and at just table level
--select concat(M.TABLE_SCHEMA,'.',M.TABLE_NAME) Tablename,
--concat(object_schema_name(referenced_object_id),Case when object_schema_name(referenced_object_id) is not null then '.' end,
--object_name(referenced_object_id)) ParentTableName
--,M.COLUMN_NAME [FieldName],case when c.CONSTRAINT_TYPE='PRIMARY KEY' then 'YES' end IsPrimaryKey 
--,case when c.CONSTRAINT_TYPE='FOREIGN KEY' then 'YES' end IsForeignKey,M.DATA_TYPE Type,M.CHARACTER_MAXIMUM_LENGTH [Length]
--,M.IS_NULLABLE AS [Required],m.IS_NULLABLE as Nullable,M.CHARACTER_MAXIMUM_LENGTH [Length],M.COLUMN_DEFAULT DEFAULTValue
--from INFORMATION_SCHEMA.columns M
--LEFT JOIN  INFORMATION_SCHEMA.TABLE_CONSTRAINTS c 
--on m.TABLE_SCHEMA=c.TABLE_SCHEMA
--and m.TABLE_NAME=c.TABLE_NAME
--LEFT JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE CC
--ON C.TABLE_SCHEMA=CC.TABLE_SCHEMA
--AND C.TABLE_NAME=CC.TABLE_NAME
--AND M.COLUMN_NAME=CC.COLUMN_NAME
--and C.CONSTRAINT_NAME=c.CONSTRAINT_NAME
--LEFT JOIN sys.foreign_keys SP
--ON object_schema_name(SP.parent_object_id)=M.TABLE_SCHEMA
--AND object_name(SP.parent_object_id)=M.TABLE_NAME
--order by m.TABLE_SCHEMA,m.TABLE_NAME,m.ORDINAL_POSITION



--Detailed column level
select distinct concat(M.TABLE_SCHEMA,'.',M.TABLE_NAME) Tablename,c.CONSTRAINT_TYPE,CC.COLUMN_NAME,
primary_table as ParentTableName ,
M.COLUMN_NAME [FieldName],case when (CC.COLUMN_NAME IS NOT NULL and Fkfinal.pk_column_name is  null) then 'YES' end IsPrimaryKey 
,case when Fkfinal.pk_column_name is not null then 'YES' end IsForeignKey,M.DATA_TYPE Type,M.CHARACTER_MAXIMUM_LENGTH [Length]
,M.IS_NULLABLE AS [Required],m.IS_NULLABLE as Nullable,M.CHARACTER_MAXIMUM_LENGTH [Length],M.COLUMN_DEFAULT DEFAULTValue
from INFORMATION_SCHEMA.columns M
LEFT JOIN  (select * from INFORMATION_SCHEMA.TABLE_CONSTRAINTS where CONSTRAINT_TYPE='PRIMARY KEY') c 
on m.TABLE_SCHEMA=c.TABLE_SCHEMA
and m.TABLE_NAME=c.TABLE_NAME
LEFT JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE CC
ON C.TABLE_SCHEMA=CC.TABLE_SCHEMA
AND C.TABLE_NAME=CC.TABLE_NAME
AND M.COLUMN_NAME=CC.COLUMN_NAME
and C.CONSTRAINT_NAME=c.CONSTRAINT_NAME
Left join (select schema_name(fk_tab.schema_id) + '.' + fk_tab.name as foreign_table,
    '>-' as rel,
    schema_name(pk_tab.schema_id) + '.' + pk_tab.name as primary_table,
    fk_cols.constraint_column_id as no, 
    fk_col.name as fk_column_name,
    ' = ' as [join],
    pk_col.name as pk_column_name,
    fk.name as fk_constraint_name
from sys.foreign_keys fk
    Left join sys.tables fk_tab
        on fk_tab.object_id = fk.parent_object_id
    Left join sys.tables pk_tab
        on pk_tab.object_id = fk.referenced_object_id
    Left join sys.foreign_key_columns fk_cols
        on fk_cols.constraint_object_id = fk.object_id
    Left join sys.columns fk_col
        on fk_col.column_id = fk_cols.parent_column_id
        and fk_col.object_id = fk_tab.object_id
    Left join sys.columns pk_col
        on pk_col.column_id = fk_cols.referenced_column_id
        and pk_col.object_id = pk_tab.object_id) Fkfinal
		on Fkfinal.foreign_table=concat(M.TABLE_SCHEMA,'.',M.TABLE_NAME)
		and Fkfinal.fk_column_name=m.COLUMN_NAME