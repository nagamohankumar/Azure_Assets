import os
from bs4 import BeautifulSoup
import csv
import pandas as pd
import glob
from pathlib import Path

def extract_data_from_html(html_file):
    with open(html_file, "r", encoding='utf-8', errors='ignore') as file:
        html_content = file.read()

    soup = BeautifulSoup(html_content, "html.parser")

    title_tag = soup.find("title")
    if title_tag:
        table_name = title_tag.text.strip()
    else:
        table_name = os.path.splitext(os.path.basename(html_file))[0]

    table = soup.find("table", class_="typelistbody")
    if table:
        rows = table.find_all("tr")[1:]  # Skip the first row

        data = []
        for row in rows:
            cells = row.find_all("td")
            if len(cells) >= 2:  # Assuming at least 2 cells are present
                code = cells[0].text.strip()
                name = cells[1].text.strip()
                data.append([code, name, table_name])

        return data
    else:
        print(f"No typelistbody table found in {html_file}")
        return None

def sending_data_to_csv(input_directory, output_file):
    html_files = [f for f in os.listdir(input_directory) if f.endswith('.html')]

    with open(output_file, "w", newline="", encoding='utf-8', errors='ignore') as csvfile:
        headerList = ["Ivos_Code", "Ivos_Name", "Guidewire_Code", "Guidewire_Name", "Type"]
        writer = csv.writer(csvfile)
        writer.writerow(headerList)  # Write the header row

        for html_file in html_files:
            data = extract_data_from_html(os.path.join(input_directory, html_file))
            if data:
                for row in data:
                    # Write empty strings for Ivos_Code and Ivos_Name, and actual data for Guidewire Code and Guidewire Name
                    writer.writerow(["", "", row[0], row[1], row[2]])

# Function to escape SQL strings
def escape_sql_string(value):
    if pd.isna(value):
        return 'NULL'
    # Ensure the value is a string
    value = str(value)
    # Replace single quotes with two single quotes
    escaped_value = value.replace("'", "''")
    return f"'{escaped_value}'"

def generate_insert_statements(df, table_name):
    insert_statements = []
    for index, row in df.iterrows():
        # Prepare the VALUES part of the SQL statement
        values = ', '.join(
            #f"'{str(value).replace('\'', '\'\'')}'" if pd.notna(value) else 'NULL'
            escape_sql_string(value)
            for value in row
        )
        # Create the INSERT statement
        sql = f"INSERT INTO {table_name} ({', '.join(df.columns)}) VALUES ({values});"
        insert_statements.append(sql)
    return insert_statements

def generate_sql_from_csv(csv_file, sql_file, table_name):


    if not os.path.isfile(csv_file):
        print(f"File not there/found: {csv_file}") 
        return

    # Read CSV file into a DataFrame
    df = pd.read_csv(csv_file)
    
    # Generate INSERT statements
    insert_statements = generate_insert_statements(df, table_name)
    
    # Write SQL statements to a file
    with open(sql_file, 'w', encoding='utf-8') as file:
        file.write(f"-- SQL INSERT statements for table: {table_name}\n")
        #file.write("BEGIN;\n")  # Optional: Start a transaction block
        for statement in insert_statements:
            file.write(statement + '\n')
        #file.write("COMMIT;\n")  # Optional: Commit the transaction block

def main(input_directory, csv_file, sql_file, table_name):
    # Extract HTML data to CSV
    sending_data_to_csv(input_directory, csv_file)
    
    # Generate SQL INSERT statements from CSV
    generate_sql_from_csv(csv_file, sql_file, table_name)

# Run the main function
if __name__ == "__main__":
    input_directory = 'C:\\Typelist\\GWTypelist'  
    csv_file = 'C:\\Typelist\\csv_all_ouput\\dbo.Master_Mapping.csv'    
    sql_file = 'C:\\Typelist\\csv_all_ouput\\Insert_Scripts_Typelist.sql'    
    table_name = 'dbo.gwtypelist'           
    main(input_directory, csv_file, sql_file, table_name)
