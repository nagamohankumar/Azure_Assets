# Databricks notebook source
dbutils.widgets.text("iteration", "", "Iteration")
dbutils.widgets.text("integration_name", "", "Integration Name")

# COMMAND ----------

import json

# Read the value of the executionid notebook widget
iteration = dbutils.widgets.get("iteration")

# Read the value of the integration_name notebook widget
integration_name = dbutils.widgets.get("integration_name")

# COMMAND ----------

# # Define the variables for the storage account and Database
# StorageAccountname = 'stmsigiseusdevgwcc01'
# Framework_database = 'frameworkdb'
# Stage_database = 'stage'
# Cmt_in_database = 'cmt_in'
# Cmt_out_database = 'cmt_out'

# # Retrieve the SAS token for the storage account
# StorageAccountSAS = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-Storageaccount-SAS")

# # Retrieve the database connection strings
# db_hostname = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-AzureSQLFrameworkServer")

# db_username = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-AZSQLFrameworkServerUsername")
# db_password = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-AZSQLFrameworkServerPassword")

# #Cmt_in 
# cmtindb_database = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-AZSQLCMTIN")

# COMMAND ----------

# MAGIC %run ./KeyVaultsecrets

# COMMAND ----------

# Define the variables for the storage account and Database
StorageAccountname = 'stmsigiseusqagwcc01'
Framework_database = 'frameworkdb'
Stage_database = 'stage'
Cmt_in_database = 'cmt_in'
Cmt_out_database = 'cmt_out'

# Retrieve the SAS token for the storage account
StorageAccountSAS = dbutils.secrets.get(scope="gwcc-qa-kv-scope", key="ADB-GWCC-Storageaccount-SAS")

# Retrieve the database connection strings
db_hostname = dbutils.secrets.get(scope="gwcc-qa-kv-scope", key="ADB-GWCC-AzureSQLFrameworkServer")

db_username = dbutils.secrets.get(scope="gwcc-qa-kv-scope", key="ADB-GWCC-AZSQLFrameworkServerUsername")
db_password = dbutils.secrets.get(scope="gwcc-qa-kv-scope", key="ADB-GWCC-AZSQLFrameworkServerPassword")

#Cmt_in 
cmtindb_database = dbutils.secrets.get(scope="gwcc-qa-kv-scope", key="ADB-GWCC-AZSQLCMTIN")

# COMMAND ----------

jdbcPort = 1433
jdbcUrl_in = f"jdbc:sqlserver://{db_hostname}:{jdbcPort};database={Cmt_in_database}"
driver="com.microsoft.sqlserver.jdbc.SQLServerDriver"
connectionProperties_in = {
    "user": db_username,
    "password": db_password,
    "driver": driver
}

# COMMAND ----------

jdbcUrl_out = f"jdbc:sqlserver://{db_hostname}:{jdbcPort};database={Cmt_out_database}"
connectionProperties_out = {
    "user": db_username,
    "password": db_password,
    "driver": driver
}

# COMMAND ----------

from pyspark.sql.functions import broadcast, lit
 
# ---- Step 1: Query WITHOUT the Name column ----
PMT_PayloadStatus_query = """
(
    SELECT PMT_Status, COUNT(1) AS PayloadCount
    FROM PMT_PayloadStatus
    WHERE PMT_Status='SENT'
    GROUP BY PMT_Status
) AS PMT_PayloadStatusdata
"""
 
# ---- Step 2: Read data ----
PMT_PayloadStatus = spark.read.jdbc(
    url=jdbcUrl_in,
    table=PMT_PayloadStatus_query,
    properties=connectionProperties_in
)
PMT_PayloadStatus.show(truncate=False)

# COMMAND ----------

# from pyspark.sql.functions import col,lit, broadcast
 
# # Load only the actual columns from the table
# PMT_PayloadStatus = spark.read.jdbc(
#     url=jdbcUrl_in,
#     table="PMT_PayloadStatus",
#     properties=connectionProperties_in
# ).filter(col("PMT_Status") == "SENT") \
# .groupBy("PMT_Status") \
# .count() \
# .withColumnRenamed("count", "PayloadCount")
 
# # ✅ Add the literal column AFTER loading
# PMT_PayloadStatus = PMT_PayloadStatus.withColumn("Name", lit("cmt_in"))
 
# # Reorder columns so Name comes first
# PMT_PayloadStatus = PMT_PayloadStatus.select("Name", "PMT_Status", "PayloadCount")
 
# # Optional: broadcast if needed
# PMT_PayloadStatus = broadcast(PMT_PayloadStatus)
 
# # PMT_PayloadStatus.show(truncate=False)

# COMMAND ----------

from pyspark.sql.functions import broadcast, lit
 
# ---- Step 1: Query WITHOUT the Name column ----
PMT_MigrationStatus_query = """
(
  SELECT PMT_Status, COUNT(1) AS PayloadCount
    FROM PMT_MigrationStatus
    GROUP BY PMT_Status
) AS PMT_MigrationStatusdata
"""
 
# ---- Step 2: Read data ----
PMT_MigrationStatus = spark.read.jdbc(
    url=jdbcUrl_out,
    table=PMT_MigrationStatus_query,
    properties=connectionProperties_out
)
# PMT_MigrationStatus.show(truncate=False)

# COMMAND ----------

from pyspark.sql.functions import lit
 
# Add Name column to each DataFrame if not already present
df1 = PMT_PayloadStatus.withColumn("Name", lit("cmt_in"))
df2 = PMT_MigrationStatus.withColumn("Name", lit("cmt_out"))
 
# Reorder columns if you want Name first
df1 = df1.select("Name", *[c for c in df1.columns if c != "Name"])
df2 = df2.select("Name", *[c for c in df2.columns if c != "Name"])
 
# Union the two DataFrames
df_union = df1.unionByName(df2)
 
# # Show result
# df_union.show(truncate=False)

# COMMAND ----------

from pyspark.sql import SparkSession
import pandas as pd
import pyspark.sql.functions as F
import csv

spark = SparkSession.builder \
    .appName("ValidationtoTransformationJob") \
    .config("spark.sql.sources.commitProtocolClass", "org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol") \
    .config("parquet.enable.summary-metadata", "false") \
    .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") \
    .getOrCreate()


#using sas token it is working
spark.conf.set(f"fs.azure.account.auth.type.{StorageAccountname}.dfs.core.windows.net", "SAS")
spark.conf.set(f"fs.azure.sas.token.provider.type.{StorageAccountname}.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")

spark.conf.set(f"fs.azure.sas.fixed.token.{StorageAccountname}.dfs.core.windows.net", StorageAccountSAS)


# Create a Spark session
spark = SparkSession.builder.getOrCreate()

# Create a dictionary to store the DataFrames
data_frames = {}


#DataLake Path
data_lake_url=f"abfs://raw@{StorageAccountname}.dfs.core.windows.net/"
print(data_lake_url)
# Specify the delimiter
delimiter = "|"  # Set your desired delimiter

#initiate Validated and transformed variable path
Reconpath=integration_name+f"/Reconciliation/"+iteration+"/"
print(Reconpath)

output_path = f"{data_lake_url}{Reconpath}PayloadCount"

# COMMAND ----------

# ---- Write to Data Lake as CSV ----
(
    df_union
    .coalesce(1)
    .write
    .mode("overwrite")
    .option("header", "true")
    .csv(output_path)
)
 
print(f"✅ CSV written to: {output_path}")

# COMMAND ----------

# ---- List of Data Tables ----
#Admin Tables Are Excluded in recon as per Ed comments
tables = [
"Activity"
,"address"
,"Adjudicator"
,"Attorney"
,"BenefitPeriod"
,"Benefits"
,"BodyPartDetails"
#,"Catastrophe"
,"Check_"
,"CheckPayee"
,"CheckSet"
,"Claim"
,"ClaimAssociation"
,"ClaimContact"
,"ClaimContactRole"
,"ClaimInAssociation"
,"ClaimWorkComp"
,"ClassCode"
,"Company"
,"CompanyVendor"
,"ConcurrentEmployment"
,"ContactAddress"
,"ContactContact"
,"EmploymentData"
,"Exposure"
,"FullDenialReason"
,"Group_"
,"History"
#,"ICDCode"
,"Incident"
,"InjuryDiagnosis"
,"InjuryIncident"
,"IVOSLocationCode_MSMM"
,"LawFirm"
,"Matter"
,"MatterExposure"
,"Note"
,"OfficialID"
,"payment"
,"Person"
,"Policy"
,"PolicyCoverage"
,"PolicyLocation"
,"PolicyPeriod"
,"Recovery"
,"RecoveryCoding"
,"RecoveryReserve"
,"RecoveryReserveSet"
,"RecoverySet"
,"reserve"
,"ReserveLine"
,"ReserveSet"
,"RiskUnit"
,"SubroAdverseParty"
,"SubroAdversePartyOverride"
,"subrogation"
,"SubrogationSummary"
,"TransactionLineItem"
,"TransactionOffset"
#,"User_"
,"WCCovEmpRU"
,"WCPClaimAddlInfo_Acc"
,"WCPExposureAddlInfo_Acc"
,"WCPReportable_Acc"
,"WCPSuspensionPeriod_Acc"
,"WorkStatus"
]

# COMMAND ----------


from pyspark.sql.functions import broadcast, lit, when
# ---- Common table name ----
common_query = "(SELECT * FROM dbo.PMT_MigrationStatus WHERE PMT_Status = 'Migrated') AS PMT_MigrationStatus"
 
common_out = broadcast(
    spark.read.jdbc(
        url=jdbcUrl_out,
        table=common_query,
        properties=connectionProperties_out
    )
)

# display(common_out)

# COMMAND ----------

counts = []  # store results

# COMMAND ----------

# ---- Process Loop ----
for tbl in tables:
    # Load table from both DBs
    df_in  = spark.read.jdbc(url=jdbcUrl_in,  table=tbl, properties=connectionProperties_in)
    df_out = spark.read.jdbc(url=jdbcUrl_out, table=tbl, properties=connectionProperties_out)
 
    # Join both with respective common tables on PMT_PayloadId
    joined_in  = df_in.join(common_out,  "PMT_PayloadId", "inner")
    joined_out = df_out.join(common_out, "PMT_PayloadId", "inner")
 
    # Count rows
    cnt_in  = joined_in.count()
    cnt_out = joined_out.count()
 
    # Append result
    counts.append((tbl, cnt_in, cnt_out))
 
# ---- Create Final Comparison DataFrame ----
result_df = spark.createDataFrame(counts, ["TableName", "Count_IN", "Count_OUT"])
 
result_df = result_df.withColumn(
    "Match",
    when(result_df.Count_IN == result_df.Count_OUT, lit("YES")).otherwise(lit("NO"))
)
 
display(result_df)

Countsoutput_path = f"{data_lake_url}{Reconpath}/CountComparision"
 
# ---- Write to Data Lake as CSV ----
(
    result_df
    .coalesce(1)
    .write
    .mode("overwrite")
    .option("header", "true")
    .csv(Countsoutput_path)
)
 
print(f"✅ CSV written to: {Countsoutput_path}")


# COMMAND ----------

from pyspark.sql.functions import when, lit
 
counts = []
 
# ---- Process Loop ----
for tbl in tables:
    # Load table from both DBs
    df_in  = spark.read.jdbc(url=jdbcUrl_in,  table=tbl, properties=connectionProperties_in)
    df_out = spark.read.jdbc(url=jdbcUrl_out, table=tbl, properties=connectionProperties_out)
 
    # Join both with respective common tables on PMT_PayloadId
    joined_in  = df_in.join(common_out,  "PMT_PayloadId", "inner")
    joined_out = df_out.join(common_out, "PMT_PayloadId", "inner")
 
    # Count rows
    cnt_in  = joined_in.count()
    cnt_out = joined_out.count()
 
    # Append result
    counts.append((tbl, cnt_in, cnt_out))
 
 
# ---- Create Final Comparison DataFrame ----
result_df = spark.createDataFrame(counts, ["TableName", "Count_IN", "Count_OUT"])
 
result_df = result_df.withColumn(
    "Match",
    when(result_df.Count_IN == result_df.Count_OUT, lit("YES")).otherwise(lit("NO"))
)
 
display(result_df)
 
# Output Path
output_path = f"{data_lake_url}{Reconpath}/CountComparision"
 
# ---- Write to Data Lake as CSV ----
(
    result_df
    .coalesce(1)
    .write
    .mode("overwrite")
    .option("header", "true")
    .csv(output_path)
)
 
print(f"✅ CSV written to: {output_path}")