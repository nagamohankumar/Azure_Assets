import pandas as pd

# Load the datasets
OTypelist_df = pd.read_excel('dbo.MasterMapping.xlsx')
NTypelist_df = pd.read_excel('dbo.MasterMapping_New.xlsx')

# Identify new entries
# new_entries = NTypelist_df[~NTypelist_df['Guidewire_Code'].isin(OTypelist_df['Guidewire_Code'])]
new_entries = NTypelist_df[~NTypelist_df.set_index(['Guidewire_Code', 'Type']).index.isin(OTypelist_df.set_index(['Guidewire_Code', 'Type']).index)]
#new_entries.count
print(new_entries)
# Identify changed entries
# merged_df = pd.merge(OTypelist_df, NTypelist_df, on='Guidewire_Code', suffixes=('_OTypelist', '_NTypelist'))
# changed_entries = merged_df[(
#     (merged_df['Guidewire_Name_OTypelist'] != merged_df['Guidewire_Name_NTypelist']) |
#     (merged_df['Type_OTypelist'] != merged_df['Type_NTypelist'])
# )]

# print("Merged Columns:", merged_df.columns)

# # Update columns based on actual names
# changed_entries = changed_entries[['Ivos_Code_NTypelist', 'Ivos_Name_NTypelist', 'Guidewire_Code', 'Guidewire_Name_NTypelist', 'Type_NTypelist']]
# changed_entries.columns = ['Ivos_Code', 'Ivos_Name', 'Guidewire_Code', 'Guidewire_Name', 'Type']

# Combine new and changed entries
# Ensure new_entries has the correct columns
new_entries = new_entries[['Ivos_Code', 'Ivos_Name', 'Guidewire_Code', 'Guidewire_Name', 'Type']]
new_entries.columns = ['Ivos_Code', 'Ivos_Name', 'Guidewire_Code', 'Guidewire_Name', 'Type']  # Rename columns to match

# Concatenate new and changed entries
changes_df = pd.concat([new_entries], ignore_index=True)

# Save to new Excel file
changes_df.to_excel('MasterMapping_changes.xlsx', index=False)