# Databricks notebook source
dbutils.widgets.text("iteration", "", "Iteration")
dbutils.widgets.text("integration_name", "", "Integration Name")

# COMMAND ----------

import json

# Read the value of the executionid notebook widget
iteration = dbutils.widgets.get("iteration")

# Read the value of the integration_name notebook widget
integration_name = dbutils.widgets.get("integration_name")

# COMMAND ----------

# # Define the variables for the storage account and Database
# StorageAccountname = 'stmsigiseusdevgwcc01'
# Framework_database = 'frameworkdb'
# Stage_database = 'stage'
# Cmt_in_database = 'cmt_in'
# Cmt_out_database = 'cmt_out'

# # Retrieve the SAS token for the storage account
# StorageAccountSAS = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-Storageaccount-SAS")

# # Retrieve the database connection strings
# db_hostname = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-AzureSQLFrameworkServer")

# db_username = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-AZSQLFrameworkServerUsername")
# db_password = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-AZSQLFrameworkServerPassword")

# #Cmt_in 
# cmtindb_database = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-AZSQLCMTIN")

# COMMAND ----------

# MAGIC %run ./KeyVaultsecrets

# COMMAND ----------

# Define the variables for the storage account and Database
StorageAccountname = 'stmsigiseusqagwcc01'
Framework_database = 'frameworkdb'
Stage_database = 'stage'
Cmt_in_database = 'cmt_in'
Cmt_out_database = 'cmt_out'

# Retrieve the SAS token for the storage account
StorageAccountSAS = dbutils.secrets.get(scope="gwcc-qa-kv-scope", key="ADB-GWCC-Storageaccount-SAS")

# Retrieve the database connection strings
db_hostname = dbutils.secrets.get(scope="gwcc-qa-kv-scope", key="ADB-GWCC-AzureSQLFrameworkServer")

db_username = dbutils.secrets.get(scope="gwcc-qa-kv-scope", key="ADB-GWCC-AZSQLFrameworkServerUsername")
db_password = dbutils.secrets.get(scope="gwcc-qa-kv-scope", key="ADB-GWCC-AZSQLFrameworkServerPassword")

#Cmt_in 
cmtindb_database = dbutils.secrets.get(scope="gwcc-qa-kv-scope", key="ADB-GWCC-AZSQLCMTIN")

# COMMAND ----------

jdbcPort = 1433
jdbcUrl_in = f"jdbc:sqlserver://{db_hostname}:{jdbcPort};database={Cmt_in_database}"
driver="com.microsoft.sqlserver.jdbc.SQLServerDriver"
connectionProperties_in = {
    "user": db_username,
    "password": db_password,
    "driver": driver
}

# COMMAND ----------

jdbcUrl_out = f"jdbc:sqlserver://{db_hostname}:{jdbcPort};database={Cmt_out_database}"
connectionProperties_out = {
    "user": db_username,
    "password": db_password,
    "driver": driver
}

# COMMAND ----------


from pyspark.sql.functions import broadcast, lit, when
# ---- Common table name ----
common_query = "(SELECT PMT_PayloadId as ClaimNumber FROM dbo.PMT_MigrationStatus WHERE PMT_Status = 'Migrated') AS PMT_MigrationStatus"
 
common_out = broadcast(
    spark.read.jdbc(
        url=jdbcUrl_out,
        table=common_query,
        properties=connectionProperties_out
    )
)

# COMMAND ----------

display(common_out)

# COMMAND ----------

from pyspark.sql import SparkSession
import pandas as pd
import pyspark.sql.functions as F
import csv

spark = SparkSession.builder \
    .appName("ValidationtoTransformationJob") \
    .config("spark.sql.sources.commitProtocolClass", "org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol") \
    .config("parquet.enable.summary-metadata", "false") \
    .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") \
    .getOrCreate()


#using sas token it is working
spark.conf.set(f"fs.azure.account.auth.type.{StorageAccountname}.dfs.core.windows.net", "SAS")
spark.conf.set(f"fs.azure.sas.token.provider.type.{StorageAccountname}.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")

spark.conf.set(f"fs.azure.sas.fixed.token.{StorageAccountname}.dfs.core.windows.net", StorageAccountSAS)


# Create a Spark session
spark = SparkSession.builder.getOrCreate()

# Create a dictionary to store the DataFrames
data_frames = {}


#DataLake Path
data_lake_url=f"abfs://raw@{StorageAccountname}.dfs.core.windows.net/"
print(data_lake_url)
# Specify the delimiter
delimiter = "|"  # Set your desired delimiter

#initiate Validated and transformed variable path
Reconpath=integration_name+f"/Reconciliation/"+iteration+f"/"
Reconpath=Reconpath.replace(" ","")

print(Reconpath)

# COMMAND ----------

from pyspark.sql.functions import coalesce, col, lit, when, broadcast
from pyspark.sql import SparkSession
 
# -----------------------------
# Step 2: Define queries with Subqueries
# -----------------------------
queries = {
    "ClaimState": {
        "sql": "SELECT DISTINCT C.ClaimNumber, C.State FROM Claim c",
        "join_cols": ["ClaimNumber"],
        "compare_cols": ["State"]
    },
    "ExposureType": {
        "sql": "SELECT DISTINCT E.PMT_PayloadId AS ClaimNumber, E.ExposureType,E.CoverageSubType FROM Exposure E ",
        "join_cols": ["ClaimNumber", "ExposureType"],
        "compare_cols": ["CoverageSubType"]
    },
    "RolesperClaim": {
        "sql": "SELECT DISTINCT C.PMT_PayloadId AS ClaimNumber, Count(C.Role) NumberofRoles FROM ClaimContactRole C group by C.PMT_PayloadId ",
        "join_cols": ["ClaimNumber"],
        "compare_cols": ["NumberofRoles"]
    },
    "Reserve_Payment": {
        "sql": """
            SELECT c.*
            FROM (
                SELECT  'reserve' AS Category, A.PMT_PayloadId AS ClaimNumber, E.ExposureType, P.Costcategory, P.CostType, SUM(claimamount) AS Amount
                FROM TransactionLineitem a
                Left JOIN Reserve p ON a.PMT_Parent = P.PMT_ID 
				left join Exposure E on ISNULL(E.PMT_ID,'')=ISNULL(p.Exposure,'')
				where  PMT_Parent_Type = 'reserve'
                GROUP BY P.CostType, P.CostCategory, A.PMT_PayloadId, E.ExposureType
                UNION ALL
                SELECT 'Payment' AS Category, A.PMT_PayloadId AS ClaimNumber, E.ExposureType, P.Costcategory, P.CostType, SUM(claimamount) AS Amount
                FROM TransactionLineitem a
                LEFT JOIN Payment p ON a.PMT_Parent = P.PMT_ID 
				left join Exposure E on ISNULL(E.PMT_ID,'')=ISNULL(p.Exposure,'')
				where  PMT_Parent_Type = 'Payment'
                GROUP BY P.CostType, P.CostCategory, A.PMT_PayloadId, E.ExposureType
            ) c
        """,
        "join_cols": ["Category", "ClaimNumber", "Costcategory", "CostType", "ExposureType"],
        "compare_cols": ["Amount"],
        "null_safe": ["ExposureType"]
    },
    "RecoveryReserve_Recovery": {
        "sql": """
            SELECT c.*
            FROM (
                SELECT 'recoveryreserve' AS Category, A.PMT_PayloadId AS ClaimNumber, E.ExposureType, P.Costcategory, P.CostType, p.RecoveryCategory, SUM(claimamount) AS Amount
                FROM TransactionLineitem a
                Left JOIN recoveryReserve p ON a.PMT_Parent = P.PMT_ID 
				left join Exposure E on ISNULL(E.PMT_ID,'')=ISNULL(p.Exposure,'')
				where PMT_Parent_Type = 'recoveryreserve'
                GROUP BY P.CostType, P.CostCategory, A.PMT_PayloadId, E.ExposureType, p.RecoveryCategory
                UNION ALL
                SELECT 'recovery' AS Category, A.PMT_PayloadId AS ClaimNumber, E.ExposureType, P.Costcategory, P.CostType, P.RecoveryCategory, SUM(claimamount) AS Amount
                FROM TransactionLineitem a
                JOIN recovery p ON a.PMT_Parent = P.PMT_ID  
				left join Exposure E on ISNULL(E.PMT_ID,'')=ISNULL(p.Exposure,'')
				where PMT_Parent_Type = 'recovery'
                GROUP BY P.CostType, P.CostCategory, A.PMT_PayloadId, E.ExposureType, p.RecoveryCategory
            ) c
        """,
        "join_cols": ["Category", "ClaimNumber", "Costcategory", "CostType", "RecoveryCategory", "ExposureType"],
        "compare_cols": ["Amount"],
        "null_safe": ["ExposureType"]
    }
}

# COMMAND ----------

# DBTITLE 1,working main query
from pyspark.sql.functions import col, when, broadcast

comparison_results = {}

for q_name, q_info in queries.items():

    print(f"\nProcessing {q_name} ...")

    df_in = spark.read.jdbc(
        url=jdbcUrl_in,
        table=f"({q_info['sql']}) tmp",
        properties=connectionProperties_in
    )

    df_out = spark.read.jdbc(
        url=jdbcUrl_out,
        table=f"({q_info['sql']}) tmp",
        properties=connectionProperties_out
    )

    # Filter using original ClaimNumber
    common_keys = common_out.select("ClaimNumber").distinct()
    df_in = df_in.join(broadcast(common_keys), "ClaimNumber", "inner")
    df_out = df_out.join(broadcast(common_keys), "ClaimNumber", "inner")

    # Rename all join columns in df_in and df_out
    for jc in q_info["join_cols"]:
        df_in = df_in.withColumnRenamed(jc, f"{jc}_in")
        df_out = df_out.withColumnRenamed(jc, f"{jc}_out")

    compare_cols = q_info.get("compare_cols")
    if compare_cols is None:
        compare_cols = [c for c in df_in.columns if c not in [f"{jc}_in" for jc in q_info["join_cols"]]]

    # Rename compare columns only if not already renamed
    for col_name in compare_cols:
        if not col_name.endswith("_IN"):
            df_in = df_in.withColumnRenamed(col_name, f"{col_name}_IN")
        if not col_name.endswith("_OUT"):
            df_out = df_out.withColumnRenamed(col_name, f"{col_name}_OUT")

    # ✅ NULL-SAFE JOIN FIX
    join_condition = None
    for jc in q_info["join_cols"]:
        jc_in = f"{jc}_in"
        jc_out = f"{jc}_out"
        if "null_safe" in q_info and jc in q_info["null_safe"]:
            cond = col(f"df_in.{jc_in}").eqNullSafe(col(f"df_out.{jc_out}"))
        else:
            cond = col(f"df_in.{jc_in}") == col(f"df_out.{jc_out}")
        join_condition = cond if join_condition is None else join_condition & cond

    combined_df = df_in.alias("df_in").join(df_out.alias("df_out"), join_condition, "outer")

    mismatch_cond = None
    for col_name in compare_cols:
        col_in = f"{col_name}_IN" if not col_name.endswith("_IN") else col_name
        col_out = f"{col_name}_OUT" if not col_name.endswith("_OUT") else col_name
        cond = ~combined_df[col_in].eqNullSafe(combined_df[col_out])
        mismatch_cond = cond if mismatch_cond is None else mismatch_cond | cond

    combined_df = combined_df.withColumn("Mismatch", when(mismatch_cond, "YES").otherwise("NO"))

    comparison_results[q_name] = combined_df

    combined_df.show(truncate=False)

    output_path = f"{data_lake_url}{Reconpath}{q_name}/"
    combined_df.coalesce(1).write.mode("overwrite").option("header", "true").csv(output_path)

# COMMAND ----------

# DBTITLE 1,working but columnname is same
from pyspark.sql.functions import col, when, broadcast

comparison_results = {}

for q_name, q_info in queries.items():

    print(f"\nProcessing {q_name} ...")

    df_in = spark.read.jdbc(

        url=jdbcUrl_in,

        table=f"({q_info['sql']}) tmp",

        properties=connectionProperties_in

    )

    df_out = spark.read.jdbc(

        url=jdbcUrl_out,

        table=f"({q_info['sql']}) tmp",

        properties=connectionProperties_out

    )

    common_keys = common_out.select("ClaimNumber").distinct()

    df_in = df_in.join(broadcast(common_keys), "ClaimNumber", "inner")

    df_out = df_out.join(broadcast(common_keys), "ClaimNumber", "inner")

    compare_cols = q_info.get("compare_cols")

    if compare_cols is None:

        compare_cols = [c for c in df_in.columns if c not in q_info["join_cols"]]

    for col_name in compare_cols:

        df_in = df_in.withColumnRenamed(col_name, f"{col_name}_IN")

        df_out = df_out.withColumnRenamed(col_name, f"{col_name}_OUT")

    # ✅ NULL-SAFE JOIN FIX

    join_condition = None

    for jc in q_info["join_cols"]:

        if "null_safe" in q_info and jc in q_info["null_safe"]:

            cond = col(f"df_in.{jc}").eqNullSafe(col(f"df_out.{jc}"))

        else:

            cond = col(f"df_in.{jc}") == col(f"df_out.{jc}")

        join_condition = cond if join_condition is None else join_condition & cond

    combined_df = df_in.alias("df_in").join(df_out.alias("df_out"), join_condition, "outer")

    mismatch_cond = None

    for col_name in compare_cols:

        cond = ~combined_df[f"{col_name}_IN"].eqNullSafe(combined_df[f"{col_name}_OUT"])

        mismatch_cond = cond if mismatch_cond is None else mismatch_cond | cond

    combined_df = combined_df.withColumn("Mismatch", when(mismatch_cond, "YES").otherwise("NO"))

    comparison_results[q_name] = combined_df

    combined_df.show(truncate=False)

    output_path = f"{data_lake_url}{Reconpath}{q_name}/"

    combined_df.coalesce(1).write.mode("overwrite").option("header","true").csv(output_path)

# COMMAND ----------

from pyspark.sql.functions import coalesce, col, lit, when, broadcast
from pyspark.sql import SparkSession
 
comparison_results = {}
 
for q_name, q_info in queries.items():
 
    print(f"\nProcessing {q_name} ...")
 
    df_in = spark.read.jdbc(
 
        url=jdbcUrl_in,
 
        table=f"({q_info['sql']}) tmp",
 
        properties=connectionProperties_in
 
    )
 
    df_out = spark.read.jdbc(
 
        url=jdbcUrl_out,
 
        table=f"({q_info['sql']}) tmp",
 
        properties=connectionProperties_out
 
    )
 
    # ✅ Filter both using common table BEFORE joins
 
    common_keys = common_out.select("ClaimNumber").distinct()
 
    df_in = df_in.join(broadcast(common_keys), "ClaimNumber", "inner")
 
    df_out = df_out.join(broadcast(common_keys), "ClaimNumber", "inner")
 
    # Determine columns to compare
 
    compare_cols = q_info.get("compare_cols")
 
    if compare_cols is None:
 
        compare_cols = [c for c in df_in.columns if c not in q_info["join_cols"]]
 
    # Rename columns for comparison
 
    for col_name in compare_cols:
 
        df_in = df_in.withColumnRenamed(col_name, f"{col_name}_IN")
 
        df_out = df_out.withColumnRenamed(col_name, f"{col_name}_OUT")
 
    # Join IN and OUT datasets
 
    combined_df = df_in.join(df_out, on=q_info["join_cols"], how="outer")
 
    # Mismatch Flag
 
    mismatch_cond = None
 
    for col_name in compare_cols:
 
        cond = combined_df[f"{col_name}_IN"] != combined_df[f"{col_name}_OUT"]
 
        mismatch_cond = cond if mismatch_cond is None else mismatch_cond | cond
 
    combined_df = combined_df.withColumn("Mismatch", when(mismatch_cond, "YES").otherwise("NO"))
 
    comparison_results[q_name] = combined_df
 
    combined_df.show(truncate=False)
 
    # Save to Data Lake
 
    output_path = f"{data_lake_url}{Reconpath}{q_name}/"
 
    (
 
        combined_df
 
        .coalesce(1)
 
        .write
 
        .mode("overwrite")
 
        .option("header", "true")
 
        .csv(output_path)
 
    )

# COMMAND ----------

from pyspark.sql.functions import coalesce, col, lit, when, broadcast
from pyspark.sql import SparkSession
 
comparison_results = {}
 
# -----------------------------
# Step 3: Loop over queries
# -----------------------------
for q_name, q_info in queries.items():
    print(f"\nProcessing {q_name} ...")
 
    # Load data from IN and OUT (wrap query in parentheses with alias)
    df_in = spark.read.jdbc(
        url=jdbcUrl_in,
        table=f"({q_info['sql']}) tmp",
        properties=connectionProperties_in
    )
 
    df_out = spark.read.jdbc(
        url=jdbcUrl_out,
        table=f"({q_info['sql']}) tmp",
        properties=connectionProperties_out
    )
    # Build join expression for multi-column joins (if any)
    join_expr = None
    for col_name in q_info["join_cols"]:
        if "null_safe" in q_info and col_name in q_info["null_safe"]:
            expr_part = coalesce(col(f"t.{col_name}"), lit(-1)) == coalesce(col(f"c.{col_name}"), lit(-1))
        else:
            expr_part = col(f"t.{col_name}") == col(f"c.{col_name}")
        join_expr = expr_part if join_expr is None else join_expr & expr_part
 
    # -----------------------------
    # Join with common table only on ClaimNumber
    # -----------------------------
    df_in = df_in.join(
        broadcast(common_out.select("ClaimNumber").distinct()),  # only filter keys
        on="ClaimNumber",
        how="inner"
    )
 
    df_out = df_out.join(
        broadcast(common_out.select("ClaimNumber").distinct()),  # only filter keys
        on="ClaimNumber",
        how="inner"
    )
 
    # Columns to compare
    compare_cols = q_info.get("compare_cols")
    if compare_cols is None:
        # Compare all except join columns
        compare_cols = [c for c in df_in.columns if c not in q_info["join_cols"]]
 
    # Rename columns for IN/OUT
    for col_name in compare_cols:
        df_in = df_in.withColumnRenamed(col_name, f"{col_name}_IN")
        df_out = df_out.withColumnRenamed(col_name, f"{col_name}_OUT")
 
    # Join IN and OUT on join columns
    combined_df = df_in.join(df_out, on=q_info["join_cols"], how="outer")
 
    # Add mismatch column
    mismatch_cond = None
    for col_name in compare_cols:
        cond = combined_df[f"{col_name}_IN"] != combined_df[f"{col_name}_OUT"]
        mismatch_cond = cond if mismatch_cond is None else mismatch_cond | cond
 
    combined_df = combined_df.withColumn("Mismatch", when(mismatch_cond, "YES").otherwise("NO"))
 
    comparison_results[q_name] = combined_df
 
    print(f"Sample mismatches for {q_name}:")
    #combined_df.filter(col("Mismatch") == "YES").show(truncate=False)
    combined_df.show(truncate=False)
    # -----------------------------
    # Save to Data Lake
    # -----------------------------
    output_path = f"{data_lake_url}{Reconpath}{q_name}/"
    (
    combined_df
    .coalesce(1)
    .write
    .mode("overwrite")
    .option("header", "true")
    .csv(output_path)
    )

# COMMAND ----------

