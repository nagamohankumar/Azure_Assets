# Databricks notebook source
dbutils.widgets.text("file_names", "[]", "File Names (Array)")
dbutils.widgets.text("sql_query", "", "SQL Query")
dbutils.widgets.text("executionid", "", "ExecutionID")
dbutils.widgets.text("transformed_filename", "", "Transformed FileName")
dbutils.widgets.text("integration_name", "", "Integration Name")
dbutils.widgets.text("notebookname_sqlquery", "", "Notebookname SQLquery")

# COMMAND ----------

import json

# Read the value of the file_names notebook widget
file_names_json = dbutils.widgets.get("file_names")

# Parse the JSON string to get the array
file_names = json.loads(file_names_json)

# Read the value of the sql_query notebook widget
sql_query = dbutils.widgets.get("sql_query")

# Read the value of the executionid notebook widget
executionid = dbutils.widgets.get("executionid")

# Read the value of the transformed_filename notebook widget
transformed_filename = dbutils.widgets.get("transformed_filename")

# Read the value of the integration_name notebook widget
integration_name = dbutils.widgets.get("integration_name")

# Read the value of the sql_query notebook widget
notebookname_sqlquery = dbutils.widgets.get("notebookname_sqlquery")

# Print the values for verification
print("File Names:", file_names)
print("SQL Query:", sql_query)
print("notebookname_sqlquery", notebookname_sqlquery)


# COMMAND ----------

# # Define the variables for the storage account and Database
# StorageAccountname = 'stmsigiseusdevgwcc01'
# Framework_database = 'frameworkdb'
# Stage_database = 'stage'
# Cmt_in_database = 'cmt_in'
# Cmt_out_database = 'cmt_out'

# # Retrieve the SAS token for the storage account
# StorageAccountSAS = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-Storageaccount-SAS")

# # Retrieve the database connection strings
# db_hostname = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-AzureSQLFrameworkServer")

# db_username = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-AZSQLFrameworkServerUsername")
# db_password = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-AZSQLFrameworkServerPassword")

# #Cmt_in 
# cmtindb_database = dbutils.secrets.get(scope="gwcc-keyvault-secret", key="ADB-GWCC-AZSQLCMTIN")

# COMMAND ----------

# MAGIC %run ./KeyVaultsecrets

# COMMAND ----------

# MAGIC %run ./SQL_UDF_Format_Time_Function

# COMMAND ----------

# notebook_name = notebookname_sqlquery
 
# dbutils.notebook.run(f"./SQL_Queries/{notebook_name}", 60)

# COMMAND ----------

import json
 
notebook_name = notebookname_sqlquery 

# Run the sub-notebook and get the result
output = dbutils.notebook.run(f"./SQL_Queries/{notebook_name}", 60)
 
# Parse the JSON string into a dictionary
result = json.loads(output)

print(result)
# Access the values
sql_query = result["sql_query"]
file_names = result["Filenames"]
 
print("Query:\n", sql_query)
print("Filenames:", file_names)

# COMMAND ----------

from pyspark.sql import SparkSession
import pandas as pd
import pyspark.sql.functions as F
import csv

spark = SparkSession.builder \
    .appName("ValidationtoTransformationJob") \
    .config("spark.sql.sources.commitProtocolClass", "org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol") \
    .config("parquet.enable.summary-metadata", "false") \
    .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") \
    .getOrCreate()


#using sas token it is working
spark.conf.set(f"fs.azure.account.auth.type.{StorageAccountname}.dfs.core.windows.net", "SAS")
spark.conf.set(f"fs.azure.sas.token.provider.type.{StorageAccountname}.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")

spark.conf.set(f"fs.azure.sas.fixed.token.{StorageAccountname}.dfs.core.windows.net", StorageAccountSAS)


# Create a Spark session
spark = SparkSession.builder.getOrCreate()

# Create a dictionary to store the DataFrames
data_frames = {}


#DataLake Path
data_lake_url=f"abfs://raw@{StorageAccountname}.dfs.core.windows.net/"
print(data_lake_url)
# Specify the delimiter
delimiter = "|"  # Set your desired delimiter

#initiate Validated and transformed variable path
validated_path=integration_name+f"/"+executionid+f"/Raw-Validated/"
transformed_path=integration_name+f"/"+executionid+f"/Transformed/"

#Get MasterMapping/Lookup Data
mastermapping_path=data_lake_url + integration_name+"/Metadata/dbo.Master_Mapping.csv"
print(mastermapping_path)
mastermappingdf=spark.read.format("csv").option("inferSchema", "true").option("header","true").option("delimiter","|").load(mastermapping_path)
mastermappingdf.createOrReplaceTempView("dbo_Master_Mapping")

# #Get Grouppublicidmapping/Lookup Data
Grouppublicidmapping_path=data_lake_url + integration_name+"/Metadata/dbo.Grouppublicidmapping.csv"
Grouppublicidmappingdf=spark.read.format("csv").option("inferSchema", "false").option("header","true").option("delimiter","|").load(Grouppublicidmapping_path)
Grouppublicidmappingdf.createOrReplaceTempView("dbo_Grouppublicidmapping")


# Iterate over the list of filenames using an index-based loop
for i in range(len(file_names)):
    # Retrieve the current file name
    file_name = file_names[i]
    
    # Modify the file name (example: adding a prefix)
    modified_file_name = file_name
   
    
    # Generate the file path dynamically
    file_path = data_lake_url+validated_path+file_name+f".parquet"
    
    # Load the CSV file as a DataFrame with specified delimiter
    df = spark.read.option("delimiter", delimiter).parquet(file_path, header=True, inferSchema=False)
    
    # Store the DataFrame in the dictionary
    data_frames[file_name] = df
    

# Register the DataFrames as temporary tables
for file_name, df in data_frames.items():
    table_name = file_name.replace(".", "_") 
    df.createOrReplaceTempView(table_name)

# Example SQL query on one of the tables
# sql_query = """SELECT DISTINCT IV.*
# FROM ITEM I    
# left JOIN ITEM_VEHICLE IV ON IV.G_ITEM = I.G_ITEM  
# left JOIN Claim C ON C.G_CLM = I.G_CLM"""

# Execute the SQL query
result = spark.sql(sql_query)

# View the result DataFrame
# result.show()

result.repartition(1).write.options(header='True', delimiter='|',ignoreFile="true").mode('overwrite').parquet(data_lake_url +transformed_path+transformed_filename+".parquet")

# Get the count of rows
row_count = result.count()

#Set the row_count as a custom output parameter
dbutils.notebook.exit(row_count)