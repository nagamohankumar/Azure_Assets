# Database configurations
SourceDB = {
    'server':'msigis-eus-dev-gwcc-mssql.database.windows.net',
    'database':'stage',
    'user':'SmartMapperreader',
    'password':'smt@gwcc11MN'
}

TargetDB = {
    'Targetserver':'msigis-eus-dev-gwcc-mssql.database.windows.net',
    'Targetdatabase':'CMT_IN',
    'Targetuser':'SmartMapperreader',
    'Targetpassword':'smt@gwcc11MN'
}