import pyodbc
import networkx as nx
import os
import matplotlib.pyplot as plt
import openpyxl
import xlsxwriter
import time
import csv
import pandas as pd
import datetime
from DBConfig import SourceDB,TargetDB 



# Define the MSSQL connection parameters
# Create output folder if it doesn't exist
output_folder = "C:\\AMIC\\Conversion\\ER Diagrams"
os.makedirs(output_folder, exist_ok=True)

 

# Define the log file path
log_file = "C:\\AMIC\\Conversion\\Log File\\Log_ERGenerator.csv"

 

# Delete existing files in the output folder
for filename in os.listdir(output_folder):
    file_path = os.path.join(output_folder, filename)
    if os.path.isfile(file_path):
        os.remove(file_path)
server = SourceDB['server']
database = SourceDB['database']
user = SourceDB['user']
password = SourceDB['password']
connection = pyodbc.connect(f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={user};PWD={password};Trusted_Connection=no;Encrypt = Optional;')

# Define the table to include in the diagram
data = pd.read_excel('C:/AMIC/Conversion/Config/AMIC - SmartMapper.xlsm', sheet_name='Schema Input Tables')
sourcecolumn = data['Source Table'].dropna().reset_index(drop=True)

print(sourcecolumn)

Taskname = 'ERGenerator'
for i in sourcecolumn:

    start_time = datetime.datetime.now()

 

    schema_name, table_name = str(i).split(".", 1)
    table = f"{schema_name}.{table_name}"

 

    # Create a new graph
    graph = nx.DiGraph()

 

    # Add the table to the graph
    graph.add_node(table)

 

    # Get foreign key relationships
    foreign_key_query = f"""
        SELECT
            FK.TABLE_SCHEMA AS TABLE_SCHEMA,
            FK.TABLE_NAME AS TABLE_NAME,
            CU.COLUMN_NAME AS COLUMN_NAME,
            PK.TABLE_SCHEMA AS REFERENCED_TABLE_SCHEMA,
            PK.TABLE_NAME AS REFERENCED_TABLE_NAME,
            PT.COLUMN_NAME AS REFERENCED_COLUMN_NAME
        FROM
            INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS C
            INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS FK ON C.CONSTRAINT_NAME = FK.CONSTRAINT_NAME
            INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS PK ON C.UNIQUE_CONSTRAINT_NAME = PK.CONSTRAINT_NAME
            INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE CU ON C.CONSTRAINT_NAME = CU.CONSTRAINT_NAME
            INNER JOIN (
                SELECT
                    i1.TABLE_SCHEMA,
                    i1.TABLE_NAME,
                    i2.COLUMN_NAME
                FROM
                    INFORMATION_SCHEMA.TABLE_CONSTRAINTS i1
                    INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE i2 ON i1.CONSTRAINT_NAME = i2.CONSTRAINT_NAME
                WHERE
                    i1.CONSTRAINT_TYPE = 'PRIMARY KEY'
            ) PT ON PT.TABLE_SCHEMA = PK.TABLE_SCHEMA AND PT.TABLE_NAME = PK.TABLE_NAME
        WHERE
            FK.TABLE_SCHEMA = '{schema_name}' AND FK.TABLE_NAME = '{table_name}'
    """

 

    cursor = connection.cursor()
    cursor.execute(foreign_key_query)
    foreign_keys = cursor.fetchall()

 

    # Add foreign key relationships to the graph
    for fk in foreign_keys:
        table_schema = fk.TABLE_SCHEMA
        table_name = fk.TABLE_NAME
        column_name = fk.COLUMN_NAME
        referenced_table_schema = fk.REFERENCED_TABLE_SCHEMA
        referenced_table_name = fk.REFERENCED_TABLE_NAME
        referenced_column_name = fk.REFERENCED_COLUMN_NAME
        table = f"{table_schema}.{table_name}"
        referenced_table = f"{referenced_table_schema}.{referenced_table_name}"
        graph.add_edge(table, referenced_table, label=column_name)

 

    # Draw the graph
    pos = nx.spring_layout(graph)
    plt.figure(figsize=(20, 15))
    nx.draw_networkx(graph, pos, with_labels=True, node_size=1800, node_color='lightblue', edge_color='gray',
                     font_size=15, font_weight='bold')

 

    # Draw edge labels
    edge_labels = nx.get_edge_attributes(graph, 'label')
    nx.draw_networkx_edge_labels(graph, pos, edge_labels=edge_labels, font_color='red')

 

    # Set plot title and save the diagram
    plt.title("ER Database Diagram")
    output_file = os.path.join(output_folder, f"{i}.jpg")
    plt.axis('off')
    plt.savefig(output_file, format='jpg')
    plt.close()

    #start_time = datetime.datetime.now()
    end_time = datetime.datetime.now()
    time_taken = end_time - start_time

 

# Append the log data to the log CSV file
    with open(log_file, 'a', newline='') as csvfile:
       writer = csv.writer(csvfile)
       writer.writerow([Taskname,table, start_time.strftime('%Y-%m-%d %H:%M:%S'), end_time.strftime('%Y-%m-%d %H:%M:%S'), time_taken])
       #writer.writerow([table, start_time, end_time, time_taken])
    #end_time = time.time()
    #time_taken = end_time - start_time

 

    # Append the log data to the log CSV file
    #with open(log_file, 'a', newline='') as csvfile:
       #writer = csv.writer(csvfile)
       #writer.writerow([table, start_time, end_time, time_taken])

 

connection.close()