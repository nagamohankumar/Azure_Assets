import pandas as pd
import pyodbc
import openpyxl
from openpyxl import *
import xlsxwriter
import datetime
from DBConfig import SourceDB,TargetDB 

# Define the log file path
log_file = "C:\\AMIC\\Conversion\\Log File\\Log_ExtractReferenceData.xlsx"

# Define Log File Details
Taskname = 'ExtractReferenceData'
start_time = datetime.datetime.now()

def fetchSourcedata(exceloutputfilepath):
    #sqlconnection
    server = SourceDB['server']
    database = SourceDB['database']
    user = SourceDB['user']
    password = SourceDB['password']
    conn = pyodbc.connect(f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={user};PWD={password};Trusted_Connection=no;Encrypt = Optional;')
    cursor=conn.cursor()
    #read from xlsm
    print("connected to Source db")
    workbook=openpyxl.load_workbook('C:\\AMIC\\Conversion\\Config\\AMIC - SmartMapper.xlsm')
    worksheet=workbook['Config - Crossreference']
    #Get the last row that has data
    last_row=worksheet.max_row
    #print (last_row)
    # writer to execlfile
    writer=pd.ExcelWriter(exceloutputfilepath,engine='openpyxl',mode='a')
    dfs =pd.DataFrame(columns=['SourceCompare','SourceOutput','Type','TableName'])
    for row in range(2,last_row+1):
        Type=worksheet.cell(row=row,column=7).value
        table_name=worksheet.cell(row=row,column=1).value
        firstcolumn=worksheet.cell(row=row,column=2).value
        secondcolumn=worksheet.cell(row=row,column=3).value
        query = f"select distinct {firstcolumn},{secondcolumn} from {table_name}"
        print(query)
        pdf = pd.read_sql(query,conn)
        pdf.insert(2,'Type',Type)
        pdf.insert(3,'TableName',table_name)
        #print(pdf)
        pdf.columns = dfs.columns
        dfs = pd.concat([pdf, dfs], axis=0, ignore_index=True)
    print(dfs)
    dfs.to_excel(writer,sheet_name='Crossreference-SourceData',index=False,startrow=0)
    writer._save()
    print("Excel sheet created for source")

def fetchTargetdata(exceloutputfilepath):
    #sqlconnection
    Targetserver = TargetDB['Targetserver']
    Targetdatabase = TargetDB['Targetdatabase']
    Targetuser = TargetDB['Targetuser']
    Targetpassword = TargetDB['Targetpassword']
    Targetconn = pyodbc.connect(f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={Targetserver};DATABASE={Targetdatabase};UID={Targetuser};PWD={Targetpassword};Trusted_Connection=no;Encrypt = Optional;')
    #read from xlsm
    print("connected to Target db")
    workbook=openpyxl.load_workbook('C:\\AMIC\\Conversion\\Config\\AMIC - SmartMapper.xlsm')
    worksheet=workbook['Config - Crossreference']
    #Get the last row of configuration file
    last_row=worksheet.max_row
    print (last_row)
    # writer to execlfile
    writer=pd.ExcelWriter(exceloutputfilepath,engine='openpyxl',mode='a')
    dfs =pd.DataFrame(columns=['TargetCompare','TargetOutput','Type','TableName'])
    for row in range(2,last_row+1):
        Type=worksheet.cell(row=row,column=7).value
        table_name=worksheet.cell(row=row,column=4).value
        firstcolumn=worksheet.cell(row=row,column=5).value
        secondcolumn=worksheet.cell(row=row,column=6).value
        query = f"select distinct {firstcolumn},{secondcolumn} from {table_name}"
        print(query)
        pdf = pd.read_sql(query,Targetconn)
        pdf.insert(2,'Type',Type)
        pdf.insert(3,'TableName',table_name)
        print(pdf)
        pdf.columns = dfs.columns
        dfs = pd.concat([pdf, dfs], axis=0, ignore_index=True)
    print(dfs)
    dfs.to_excel(writer,sheet_name='Crossreference-TargetData',index=False,startrow=0)
    writer.close()
    print("Excel sheet created for target")

def fetchTargetdatasingletable(exceloutputfilepath):
    #sqlconnection
    Targetserver = TargetDB['Targetserver']
    Targetdatabase = TargetDB['Targetdatabase']
    Targetuser = TargetDB['Targetuser']
    Targetpassword = TargetDB['Targetpassword']
    Targetconn = pyodbc.connect(f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={Targetserver};DATABASE={Targetdatabase};UID={Targetuser};PWD={Targetpassword};Trusted_Connection=no;Encrypt = Optional;')
    #read from xlsm
    print("connected to Target db")
    workbook=openpyxl.load_workbook('C:\\AMIC\\Conversion\\Config\\AMIC - SmartMapper.xlsm')
    worksheet=workbook['Config - Crossreference']
    #Get the last row of configuration file
    # last_row=worksheet.max_row
    TargetComparecolumn = 'A'
    last_row = 2
    print (last_row)
    # writer to execlfile
    writer=pd.ExcelWriter(exceloutputfilepath,engine='openpyxl',mode='a')
    dfs =pd.DataFrame(columns=['TargetCompare','TargetOutput','Type','TableName'])
    for row in range(2,last_row+1):
        #Type=worksheet.cell(row=row,column=7).value
        table_name=worksheet.cell(row=row,column=4).value
        firstcolumn=worksheet.cell(row=row,column=5).value
        secondcolumn=worksheet.cell(row=row,column=6).value
        query = f"select distinct {firstcolumn},{secondcolumn},TypeList_Name as Type from {table_name}"
        print(query)
        pdf = pd.read_sql(query,Targetconn)
        #pdf.insert(2,'Type',Type)
        pdf.insert(3,'TableName',table_name)
        print(pdf)
        pdf.columns = dfs.columns
        dfs = pd.concat([pdf, dfs], axis=0, ignore_index=True)
    print(dfs)
    dfs.to_excel(writer,sheet_name='Crossreference-TargetData',index=False,startrow=0)
    writer.close()
    print("Excel sheet created for target")
#Log File Entry
workbook = xlsxwriter.Workbook(log_file)
worksheet = workbook.add_worksheet()

# Write headers
worksheet.write(0, 0, 'Task')
worksheet.write(0, 1, 'Start Time')
worksheet.write(0, 2, 'End Time')
worksheet.write(0, 3, 'Time Taken')

# Write data
end_time = datetime.datetime.now()
time_taken = end_time - start_time
row = 1
worksheet.write(row, 0, Taskname)
worksheet.write(row, 1, start_time.strftime('%Y-%m-%d %H:%M:%S'))
worksheet.write(row, 2, end_time.strftime('%Y-%m-%d %H:%M:%S'))
worksheet.write(row, 3, str(time_taken))

# Close the workbook
workbook.close()
		   

def main():
    exceloutputfilepath='C:\\AMIC\\Conversion\\Source_To_Target_Mapping.xlsx'
    fetchSourcedata(exceloutputfilepath)
    #fetchTargetdata(exceloutputfilepath)
    fetchTargetdatasingletable(exceloutputfilepath)
    pass
main()
