import pandas as pd
# import pandas_profiling
import sqlalchemy as sa
from sqlalchemy.engine import URL
from sqlalchemy import create_engine
from sqlalchemy import create_engine
import pandas as pd
import sqlalchemy as sa
from ydata_profiling import ProfileReport
import pyodbc
import os
import ydata_profiling
# import xlsxwriter
import datetime
import csv
from DBConfig import SourceDB



def fetchdata():
    # Define the log file path
    log_file = "C:\\AMIC\\Conversion\\Log File\\Log_SQLDataProfiling.csv"
    server = SourceDB['server']
    database = SourceDB['database']
    user = SourceDB['user']
    password = SourceDB['password']
    conn = pyodbc.connect(f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={user};PWD={password};Trusted_Connection=no;Encrypt = Optional;')
    # write to excelfile

    data = pd.read_excel('C:/AMIC/Conversion/Config/AMIC - SmartMapper.xlsm',sheet_name='Schema Input Tables')
    # To Access Column
    sourcecolumn = data['Source Table'] 
    with open(log_file, 'w', newline='') as csvfile:
      writer = csv.writer(csvfile)
      writer.writerow(['Task' , 'Table Name', 'Start Time', 'End Time', 'Time Taken'])  
    #Extracts the data from source column
    sourcecolumndata = ', '.join([f"'{str(value)}'" for value in sourcecolumn])
    #writer=pd.ExcelWriter(exceloutputfilepath,engine='xlsxwriter')
    # Generate the SQL query with the extracted values
    print (sourcecolumndata)
    sql_stmt=f"SELECT  (TABLE_SCHEMA+'.'+TABLE_NAME) as TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE CONCAT(TABLE_SCHEMA,'.',TABLE_NAME) IN ({sourcecolumndata})"
    dft=pd.read_sql(sql_stmt,conn)
    print (dft)

    # profiles=ProfileReport(dft,title="PandasProfilingReport")
    # profiles.to_file(output_file='report.xlsx')
    #sourceprofile= int(data['Source Data Profiling Count'].iloc[0])
    for Tablelist in dft['TABLE_NAME'].unique():
           start_time = datetime.datetime.now()
           sourceprofile_data = data.loc[data['Source Table'] == Tablelist, 'Source Data Profiling Count'].values[0]
           sourceprofile=int(sourceprofile_data)
           print(Tablelist)
           sql_stmt2=f"SELECT top {sourceprofile} * FROM {Tablelist}"
           print(sql_stmt2)
           table_data = pd.read_sql(sql_stmt2,conn,parse_dates=['ExpirationDate'])
           print(table_data)
           if table_data.empty:
               continue
           profile=ProfileReport(table_data)
           folderPath="C:\\AMIC\\Conversion\\Data Profiling\\"
           profile.to_file(f"{folderPath}{Tablelist}.html")
           end_time = datetime.datetime.now()
           time_taken = end_time - start_time
           Taskname = 'SQLDataprofiling'
 

# Append the log data to the log CSV file
           with open(log_file, 'a', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([Taskname,Tablelist, start_time.strftime('%Y-%m-%d %H:%M:%S'), end_time.strftime('%Y-%m-%d %H:%M:%S'), time_taken])

    

    
    
fetchdata()



#   with engine.begin() as conn2:
#         print(df['TABLE_NAME'])
#         for table in df['TABLE_NAME']:
#             print(table)
            
#             table_data = pd.read_sql_query(sa.text("SELECT * FROM "),conn2)
#             print(table_data)
#             # ydata_profiling.ProfileReport(table_data)
#             profile=ydata_profiling.ProfileReport(table_data)
#             profile.to_file(f"{table}_report.html")
#             print("Present Directory is "+os.getcwd())

