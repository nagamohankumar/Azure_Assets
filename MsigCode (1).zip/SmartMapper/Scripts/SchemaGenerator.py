import pandas as pd
import pyodbc
import openpyxl
from openpyxl import *
import xlsxwriter
import datetime              
import time                      
import sys
import os
from DBConfig import SourceDB,TargetDB                      
# Define the log file path                                     
log_file = "C:\\AMIC\\Conversion\\Log File\\Log_SchemaGenerator.xlsx"
# Define Log File Details
Taskname = 'SchemaGenerator'
start_time = datetime.datetime.now()
#declare db details
#source sqlconnection
server = SourceDB['server']
database = SourceDB['database']
user = SourceDB['user']
password = SourceDB['password']
conn = pyodbc.connect(f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={user};PWD={password};Trusted_Connection=no;Encrypt = Optional;')
#Target sqlconnection(if the target is csv keep below target server details blank)
Targetserver = TargetDB['Targetserver']
Targetdatabase = TargetDB['Targetdatabase']
Targetuser = TargetDB['Targetuser']
Targetpassword = TargetDB['Targetpassword']
Targetconn = pyodbc.connect(f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={Targetserver};DATABASE={Targetdatabase};UID={Targetuser};PWD={Targetpassword};Trusted_Connection=no;Encrypt = Optional;')

#source and target output needs to be populated in below sheet
exceloutputfilepath="C:\\AMIC\\Conversion\\Source_To_Target_Mapping.xlsx"
writer=pd.ExcelWriter(exceloutputfilepath,engine='xlsxwriter')

#Read input tables names from mapper
data = pd.read_excel('C:/AMIC/Conversion/Config/AMIC - SmartMapper.xlsm',sheet_name='Schema Input Tables')

#funtion to fetch the src data from database
def fetchSourceDBdata():
    # To Access Column
    sourcecolumn = data['Source Table'] 
    #Extracts the data from source column
    sourcecolumndata = ', '.join([f"'{str(value)}'" for value in sourcecolumn])

    # Generate the SQL query with the extracted values
    sql_stmt=f"select [Table],[Column],DataType,[Length],Case when IsForeignKey='Yes' then 'ForeignKey' when IsPrimaryKey='YES' THEN 'Primarykey' End [Constraint],Case  when [Nullable]='NO' THEN 'YES' else 'NO' END Mandatory  from (select distinct concat(M.TABLE_SCHEMA,'.',M.TABLE_NAME) [Table],M.COLUMN_NAME [Column],CASE WHEN M.DATA_TYPE LIKE 'bigint%' THEN 'bigint' WHEN M.DATA_TYPE LIKE 'datetime2%' THEN 'datetime' WHEN M.DATA_TYPE LIKE 'decimal%' THEN 'decimal' WHEN M.DATA_TYPE LIKE 'numeric%' THEN 'numeric'ELSE M.DATA_TYPE END AS DataType,M.CHARACTER_MAXIMUM_LENGTH [Length],M.IS_NULLABLE AS [Required],M.IS_NULLABLE as Nullable,case when (CC.COLUMN_NAME IS NOT NULL and Fkfinal.pk_column_name is  null) then 'YES' end IsPrimaryKey ,case when Fkfinal.pk_column_name is not null then 'YES' end IsForeignKey from INFORMATION_SCHEMA.COLUMNS M LEFT JOIN  (select * from INFORMATION_SCHEMA.TABLE_CONSTRAINTS where CONSTRAINT_TYPE='PRIMARY KEY') c on M.TABLE_SCHEMA=c.TABLE_SCHEMA and M.TABLE_NAME=c.TABLE_NAME LEFT JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE CC ON c.TABLE_SCHEMA=CC.TABLE_SCHEMA AND c.TABLE_NAME=CC.TABLE_NAME AND M.COLUMN_NAME=CC.COLUMN_NAME and c.CONSTRAINT_NAME=c.CONSTRAINT_NAME Left join (select schema_name(fk_tab.schema_id) + '.' + fk_tab.name as foreign_table,     '>-' as rel,     schema_name(pk_tab.schema_id) + '.' + pk_tab.name as primary_table,     fk_cols.constraint_column_id as no,      fk_col.name as fk_column_name,     ' = ' as [join],     pk_col.name as pk_column_name,     fk.name as fk_constraint_name from sys.foreign_keys fk     Left join sys.tables fk_tab         on fk_tab.object_id = fk.parent_object_id     Left join sys.tables pk_tab         on pk_tab.object_id = fk.referenced_object_id     Left join sys.foreign_key_columns fk_cols         on fk_cols.constraint_object_id = fk.object_id     Left join sys.columns fk_col         on fk_col.column_id = fk_cols.parent_column_id         and fk_col.object_id = fk_tab.object_id     Left join sys.columns pk_col         on pk_col.column_id = fk_cols.referenced_column_id         and pk_col.object_id = pk_tab.object_id) Fkfinal 		on Fkfinal.foreign_table=concat(M.TABLE_SCHEMA,'.',M.TABLE_NAME) 		and Fkfinal.fk_column_name=M.COLUMN_NAME 		WHERE concat(M.TABLE_SCHEMA,'.',M.TABLE_NAME) in ({sourcecolumndata}))a"

    dft=pd.read_sql(sql_stmt,conn)
    dft.to_excel(writer,sheet_name='Source_Metadata',index=False)

#funtion to fetch the src data from file
def fetchSourceCSVdata():
    print("Dummy function created if the requirement is there will add the code")

#Function to fetch target data from database
def fetchTargetDBdata():
    # To Access Column
    targetcolumn = data['Target Table'] 
    #Extracts the data from source column
    targetcolumndata = ', '.join([f"'{str(value)}'" for value in targetcolumn])   
#    Targetsql_stmt=f"select [Table],[Column],concat(DataType,'(',[Length],')') DataType,when IsPrimaryKey='YES' THEN 'Primarykey' End [IsPrimaryKey],Case when IsForeignKey='Yes' then 'ForeignKey' End [ForeignKey],Case  when [Nullable]='NO' THEN 'YES' else 'NO' END [Mandatory],'' as TypeKey,'' as UIMandatory  from (select distinct concat(M.TABLE_SCHEMA,'.',M.TABLE_NAME) [Table],M.COLUMN_NAME [Column],M.DATA_TYPE DataType,M.CHARACTER_MAXIMUM_LENGTH [Length],M.IS_NULLABLE AS [Required],M.IS_NULLABLE as Nullable,case when (CC.COLUMN_NAME IS NOT NULL and Fkfinal.pk_column_name is  null) then 'YES' end IsPrimaryKey ,case when Fkfinal.pk_column_name is not null then 'YES' end IsForeignKey from INFORMATION_SCHEMA.COLUMNS M LEFT JOIN  (select * from INFORMATION_SCHEMA.TABLE_CONSTRAINTS where CONSTRAINT_TYPE='PRIMARY KEY') c on M.TABLE_SCHEMA=c.TABLE_SCHEMA and M.TABLE_NAME=c.TABLE_NAME LEFT JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE CC ON c.TABLE_SCHEMA=CC.TABLE_SCHEMA AND c.TABLE_NAME=CC.TABLE_NAME AND M.COLUMN_NAME=CC.COLUMN_NAME and c.CONSTRAINT_NAME=c.CONSTRAINT_NAME Left join (select schema_name(fk_tab.schema_id) + '.' + fk_tab.name as foreign_table,     '>-' as rel,     schema_name(pk_tab.schema_id) + '.' + pk_tab.name as primary_table,     fk_cols.constraint_column_id as no,      fk_col.name as fk_column_name,     ' = ' as [join],     pk_col.name as pk_column_name,     fk.name as fk_constraint_name from sys.foreign_keys fk     Left join sys.tables fk_tab         on fk_tab.object_id = fk.parent_object_id     Left join sys.tables pk_tab         on pk_tab.object_id = fk.referenced_object_id     Left join sys.foreign_key_columns fk_cols         on fk_cols.constraint_object_id = fk.object_id     Left join sys.columns fk_col         on fk_col.column_id = fk_cols.parent_column_id         and fk_col.object_id = fk_tab.object_id     Left join sys.columns pk_col         on pk_col.column_id = fk_cols.referenced_column_id         and pk_col.object_id = pk_tab.object_id) Fkfinal 		on Fkfinal.foreign_table=concat(M.TABLE_SCHEMA,'.',M.TABLE_NAME) 		and Fkfinal.fk_column_name=M.COLUMN_NAME 		WHERE concat(M.TABLE_SCHEMA,'.',M.TABLE_NAME) in ({targetcolumndata}) )a"
    Targetsql_stmt=f"SELECT [Table], [Column], CONCAT(DataType, '(', Length, ')') AS DataType, " \
               f"CASE WHEN IsPrimaryKey='YES' THEN 'Primarykey' END AS IsPrimaryKey, " \
               f"CASE WHEN IsForeignKey='Yes' THEN 'ForeignKey' END AS ForeignKey, " \
               f"CASE WHEN [Nullable]='NO' THEN 'YES' ELSE 'NO' END AS DBMandatory, " \
               f"'' AS TypeKey, '' AS UIMandatory " \
               f"FROM (SELECT DISTINCT CONCAT(M.TABLE_SCHEMA, '.', M.TABLE_NAME) AS [Table], " \
               f"M.COLUMN_NAME AS [Column],CASE WHEN M.DATA_TYPE LIKE 'int%' THEN 'int' WHEN M.DATA_TYPE LIKE 'datetime%' THEN 'datetime' WHEN M.DATA_TYPE LIKE 'numeric%' THEN 'numeric' ELSE M.DATA_TYPE END AS DataType,M.CHARACTER_MAXIMUM_LENGTH AS [Length], " \
               f"M.IS_NULLABLE AS [Required], M.IS_NULLABLE AS Nullable, " \
               f"CASE WHEN (CC.COLUMN_NAME IS NOT NULL AND Fkfinal.pk_column_name IS NULL) THEN 'YES' END AS IsPrimaryKey, " \
               f"CASE WHEN Fkfinal.pk_column_name IS NOT NULL THEN 'YES' END AS IsForeignKey " \
               f"FROM INFORMATION_SCHEMA.COLUMNS M " \
               f"LEFT JOIN (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_TYPE='PRIMARY KEY') c " \
               f"ON M.TABLE_SCHEMA=c.TABLE_SCHEMA AND M.TABLE_NAME=c.TABLE_NAME " \
               f"LEFT JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE CC " \
               f"ON c.TABLE_SCHEMA=CC.TABLE_SCHEMA AND c.TABLE_NAME=CC.TABLE_NAME AND M.COLUMN_NAME=CC.COLUMN_NAME AND c.CONSTRAINT_NAME=c.CONSTRAINT_NAME " \
               f"LEFT JOIN (SELECT schema_name(fk_tab.schema_id) + '.' + fk_tab.name AS foreign_table, " \
               f"'>-' AS rel, schema_name(pk_tab.schema_id) + '.' + pk_tab.name AS primary_table, " \
               f"fk_cols.constraint_column_id AS no, fk_col.name AS fk_column_name, ' = ' AS [join], " \
               f"pk_col.name AS pk_column_name, fk.name AS fk_constraint_name " \
               f"FROM sys.foreign_keys fk " \
               f"LEFT JOIN sys.tables fk_tab ON fk_tab.object_id=fk.parent_object_id " \
               f"LEFT JOIN sys.tables pk_tab ON pk_tab.object_id=fk.referenced_object_id " \
               f"LEFT JOIN sys.foreign_key_columns fk_cols ON fk_cols.constraint_object_id=fk.object_id " \
               f"LEFT JOIN sys.columns fk_col ON fk_col.column_id=fk_cols.parent_column_id AND fk_col.object_id=fk_tab.object_id " \
               f"LEFT JOIN sys.columns pk_col ON pk_col.column_id=fk_cols.referenced_column_id AND pk_col.object_id=pk_tab.object_id) Fkfinal " \
               f"ON Fkfinal.foreign_table=CONCAT(M.TABLE_SCHEMA, '.', M.TABLE_NAME) AND Fkfinal.fk_column_name=M.COLUMN_NAME " \
               f"WHERE CONCAT(M.TABLE_SCHEMA, '.', M.TABLE_NAME) IN ({targetcolumndata})) a"
    
    Targetdft=pd.read_sql(Targetsql_stmt,Targetconn)
    #--------changing data type format----------------------------------    
    data_type_mapping = {
        'int()': 'int',
        'datetime()': 'datetime',
        'bit()' : 'bit',
        'bigint()' : 'bigint',
        'decimal()' : 'decimal',
        'numeric()' :'numeric'
    }
    Targetdft['DataType'] = Targetdft['DataType'].replace(data_type_mapping)
    Targetdft.to_excel(writer,sheet_name='Target_Metadata',index=False)
    
    # create sheets for each table.
    for Tablelist in Targetdft['Table'].unique():
        newdft=Targetdft[Targetdft['Table'] == Tablelist]
        if len(Tablelist) >31 : 
         newdft.to_excel (writer,sheet_name=Tablelist[0:31],index=False,startrow=11, startcol=0,header=None)
        else  :                                                                                                                                                                                             
          newdft.to_excel(writer,sheet_name=Tablelist,index=False,startrow=11, startcol=0,header=None)
    print("Excel sheet created")


#funtion to fetch the target data from database and csv file and output will be intersect of both
def fetchTargetDBCSVdata():
    # To Access Column
    targetcolumn = data['Target Table'] 
    #Extracts the data from source column
    targetcolumndata = ', '.join([f"'{str(value)}'" for value in targetcolumn])   
#    Targetsql_stmt=f"select [Table],[Column],concat(DataType,'(',[Length],')') DataType,when IsPrimaryKey='YES' THEN 'Primarykey' End [IsPrimaryKey],Case when IsForeignKey='Yes' then 'ForeignKey' End [ForeignKey],Case  when [Nullable]='NO' THEN 'YES' else 'NO' END [Mandatory],'' as TypeKey,'' as UIMandatory  from (select distinct concat(M.TABLE_SCHEMA,'.',M.TABLE_NAME) [Table],M.COLUMN_NAME [Column],M.DATA_TYPE DataType,M.CHARACTER_MAXIMUM_LENGTH [Length],M.IS_NULLABLE AS [Required],M.IS_NULLABLE as Nullable,case when (CC.COLUMN_NAME IS NOT NULL and Fkfinal.pk_column_name is  null) then 'YES' end IsPrimaryKey ,case when Fkfinal.pk_column_name is not null then 'YES' end IsForeignKey from INFORMATION_SCHEMA.COLUMNS M LEFT JOIN  (select * from INFORMATION_SCHEMA.TABLE_CONSTRAINTS where CONSTRAINT_TYPE='PRIMARY KEY') c on M.TABLE_SCHEMA=c.TABLE_SCHEMA and M.TABLE_NAME=c.TABLE_NAME LEFT JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE CC ON c.TABLE_SCHEMA=CC.TABLE_SCHEMA AND c.TABLE_NAME=CC.TABLE_NAME AND M.COLUMN_NAME=CC.COLUMN_NAME and c.CONSTRAINT_NAME=c.CONSTRAINT_NAME Left join (select schema_name(fk_tab.schema_id) + '.' + fk_tab.name as foreign_table,     '>-' as rel,     schema_name(pk_tab.schema_id) + '.' + pk_tab.name as primary_table,     fk_cols.constraint_column_id as no,      fk_col.name as fk_column_name,     ' = ' as [join],     pk_col.name as pk_column_name,     fk.name as fk_constraint_name from sys.foreign_keys fk     Left join sys.tables fk_tab         on fk_tab.object_id = fk.parent_object_id     Left join sys.tables pk_tab         on pk_tab.object_id = fk.referenced_object_id     Left join sys.foreign_key_columns fk_cols         on fk_cols.constraint_object_id = fk.object_id     Left join sys.columns fk_col         on fk_col.column_id = fk_cols.parent_column_id         and fk_col.object_id = fk_tab.object_id     Left join sys.columns pk_col         on pk_col.column_id = fk_cols.referenced_column_id         and pk_col.object_id = pk_tab.object_id) Fkfinal 		on Fkfinal.foreign_table=concat(M.TABLE_SCHEMA,'.',M.TABLE_NAME) 		and Fkfinal.fk_column_name=M.COLUMN_NAME 		WHERE concat(M.TABLE_SCHEMA,'.',M.TABLE_NAME) in ({targetcolumndata}) )a"
    Targetsql_stmt=f"SELECT [Table], [Column], CONCAT(DataType, '(', Length, ')') AS DataType, " \
               f"CASE WHEN IsPrimaryKey='YES' THEN 'Primarykey' END AS IsPrimaryKey, " \
               f"CASE WHEN IsForeignKey='Yes' THEN 'ForeignKey' END AS ForeignKey, " \
               f"CASE WHEN [Nullable]='NO' THEN 'YES' ELSE 'NO' END AS DBMandatory, " \
               f"'' AS TypeKey, '' AS UIMandatory " \
               f"FROM (SELECT DISTINCT CONCAT(M.TABLE_SCHEMA, '.', M.TABLE_NAME) AS [Table], " \
               f"M.COLUMN_NAME AS [Column],CASE WHEN M.DATA_TYPE LIKE 'int%' THEN 'int' WHEN M.DATA_TYPE LIKE 'datetime%' THEN 'datetime' WHEN M.DATA_TYPE LIKE 'numeric%' THEN 'numeric' ELSE M.DATA_TYPE END AS DataType,M.CHARACTER_MAXIMUM_LENGTH AS [Length], " \
               f"M.IS_NULLABLE AS [Required], M.IS_NULLABLE AS Nullable, " \
               f"CASE WHEN (CC.COLUMN_NAME IS NOT NULL AND Fkfinal.pk_column_name IS NULL) THEN 'YES' END AS IsPrimaryKey, " \
               f"CASE WHEN Fkfinal.pk_column_name IS NOT NULL THEN 'YES' END AS IsForeignKey " \
               f"FROM INFORMATION_SCHEMA.COLUMNS M " \
               f"LEFT JOIN (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_TYPE='PRIMARY KEY') c " \
               f"ON M.TABLE_SCHEMA=c.TABLE_SCHEMA AND M.TABLE_NAME=c.TABLE_NAME " \
               f"LEFT JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE CC " \
               f"ON c.TABLE_SCHEMA=CC.TABLE_SCHEMA AND c.TABLE_NAME=CC.TABLE_NAME AND M.COLUMN_NAME=CC.COLUMN_NAME AND c.CONSTRAINT_NAME=c.CONSTRAINT_NAME " \
               f"LEFT JOIN (SELECT schema_name(fk_tab.schema_id) + '.' + fk_tab.name AS foreign_table, " \
               f"'>-' AS rel, schema_name(pk_tab.schema_id) + '.' + pk_tab.name AS primary_table, " \
               f"fk_cols.constraint_column_id AS no, fk_col.name AS fk_column_name, ' = ' AS [join], " \
               f"pk_col.name AS pk_column_name, fk.name AS fk_constraint_name " \
               f"FROM sys.foreign_keys fk " \
               f"LEFT JOIN sys.tables fk_tab ON fk_tab.object_id=fk.parent_object_id " \
               f"LEFT JOIN sys.tables pk_tab ON pk_tab.object_id=fk.referenced_object_id " \
               f"LEFT JOIN sys.foreign_key_columns fk_cols ON fk_cols.constraint_object_id=fk.object_id " \
               f"LEFT JOIN sys.columns fk_col ON fk_col.column_id=fk_cols.parent_column_id AND fk_col.object_id=fk_tab.object_id " \
               f"LEFT JOIN sys.columns pk_col ON pk_col.column_id=fk_cols.referenced_column_id AND pk_col.object_id=pk_tab.object_id) Fkfinal " \
               f"ON Fkfinal.foreign_table=CONCAT(M.TABLE_SCHEMA, '.', M.TABLE_NAME) AND Fkfinal.fk_column_name=M.COLUMN_NAME " \
               f"WHERE CONCAT(M.TABLE_SCHEMA, '.', M.TABLE_NAME) IN ({targetcolumndata})) a"
    
    Targetdft=pd.read_sql(Targetsql_stmt,Targetconn) 

    # Read CMT data excel
    cmtdata = pd.read_excel('C:/AMIC/Conversion/MetaData/CMT_Target_data.xlsx',sheet_name='OOTB_CMT')
    # Remove unwanted space from columns and creating mandatory column   
    cmtdata.columns = cmtdata.columns.str.strip()
    cmtdata['DB Mandatory'] = cmtdata.apply(lambda row: 'YES' if row['IsNull'] == 'not null' else 'NO', axis=1)

    # select only required columns
    selected_columns = ['TableName','Field Name','Data Type','Is Primary Key','Foreign Key','DB Mandatory','Type Key','UI Mandatory']
    
    cmtdata=cmtdata[selected_columns]
    cmtdata = cmtdata.rename(columns={'Field Name': 'Column'})
    
    filtered_cmtdata = cmtdata[cmtdata['TableName'].isin(targetcolumn.apply(lambda x: x.split('.')[1]))]
    #Adding below column for joining purpose
    Targetdft['TableName']= Targetdft['Table'].str.split('.').str[1] 
   
    print(Targetdft[Targetdft['TableName'] == 'ClaimContact'])        
    print(filtered_cmtdata[filtered_cmtdata['TableName'] == 'ClaimContact'])  
    # merged_df = pd.merge(Targetdft,filtered_cmtdata, on=['TableName','Column'], how = 'inner')
    merged_df = pd.merge(filtered_cmtdata,Targetdft, on=['TableName','Column'], how = 'inner')
    print(merged_df[merged_df['Table'] == 'dbo.ClaimContact']) 
#--------changing data type format----------------------------------    
    data_type_mapping = {
        'int()': 'int',
        'datetime()': 'datetime',
        'bit()' : 'bit',
        'bigint()' : 'bigint',
        'decimal()' : 'decimal',
        'numeric()' :'numeric'
    }
    merged_df['DataType'] = merged_df['DataType'].replace(data_type_mapping)
#-------------------------------------------------------------------------------------------
    final_df = merged_df[['Table', 'Column', 'DataType', 'Is Primary Key', 'Foreign Key', 'DBMandatory', 'Type Key', 'UI Mandatory']]
    #final_df = final_df.rename(columns={'Column_x': 'Column'})
      
     
    final_df.to_excel(writer,sheet_name='Target_Metadata',index=False)
    
    # create sheets for each table.
    for Tablelist in final_df['Table'].unique():
        newdft=final_df[final_df['Table'] == Tablelist]
        newdft.to_excel(writer,sheet_name=Tablelist,index=False,startrow=11, startcol=0,header=None)
    print("Excel sheet created")

#Function to fetch the target data file   
def fetchTargetCSVdata():
    # To Access Column
    targetcolumn = data['Target Table'].apply(lambda x: x.split('.')[1])  
    
    # Read CMT data excel
    cmtdata = pd.read_excel('C:/AMIC/Conversion/MetaData/CMT_Target_data.xlsx',sheet_name='OOTB_CMT')
    # Remove unwanted space from columns and creating mandatory column   
    cmtdata.columns = cmtdata.columns.str.strip()
    cmtdata['DB Mandatory'] = cmtdata.apply(lambda row: 'YES' if row['IsNull'] == 'not null' else 'NO', axis=1)

    # select only required columns
    selected_columns = ['TableName','Field Name','Data Type','Is Primary Key','Foreign Key','DB Mandatory','Type Key','UI Mandatory']
    cmtdata=cmtdata[selected_columns]
    cmtdata = cmtdata.rename(columns={'TableName': 'Table', 'Field Name': 'Column'})
    #print(cmtdata.columns)   
    
    filtered_cmtdata = cmtdata[cmtdata['Table'].isin(targetcolumn)]    
    filtered_cmtdata.to_excel(writer,sheet_name='Target_Metadata',index=False)
    
    # create sheets for each table.
    for Tablelist in filtered_cmtdata['Table'].unique():
        newdft=filtered_cmtdata[filtered_cmtdata['Table'] == Tablelist]
        newdft.to_excel(writer,sheet_name=Tablelist,index=False,startrow=11, startcol=0,header=None)
    print("Excel sheet created")

def main():
    #Read the source and target ype from mapper
    input_df = pd.read_excel('C:/AMIC/Conversion/Config/AMIC - SmartMapper.xlsm',sheet_name='Home',nrows=3)
    
    source_df = input_df[input_df['System'] == 'Source']

    target_df = input_df[input_df['System'] == 'Target']

    source_type=source_df['Type'].str.lower()
    target_type=target_df['Type'].str.lower()
    #print(source_type,type(source_type))

    #decide which funtion to call for source data
    if source_type.eq('database').any():
        fetchSourceDBdata()
    elif source_type.eq('csv').any():
        fetchSourceCSVdata()
    else:
        print("Invalid source format")

    #decide which funtion to call for target data
    if target_type.eq('database').any():
        fetchTargetDBdata()
    elif target_type.eq('csv').any():
        fetchTargetCSVdata()
    elif target_type.eq('database-csv(gw)').any():
        fetchTargetDBCSVdata()
    else:
        print("Invalid target format")

    writer.close()
#Log File Entry
workbook = xlsxwriter.Workbook(log_file)
worksheet = workbook.add_worksheet()

# Write headers
worksheet.write(0, 0, 'Task')
worksheet.write(0, 1, 'Start Time')
worksheet.write(0, 2, 'End Time')
worksheet.write(0, 3, 'Time Taken')

# Write data
end_time = datetime.datetime.now()
time_taken = end_time - start_time
row = 1
worksheet.write(row, 0, Taskname)
worksheet.write(row, 1, start_time.strftime('%Y-%m-%d %H:%M:%S'))
worksheet.write(row, 2, end_time.strftime('%Y-%m-%d %H:%M:%S'))
worksheet.write(row, 3, str(time_taken))

# Close the workbook
workbook.close()

pass
main()
